<?php
$host= "144.91.103.25";
$user ="allshopc_cpl";
$password = "ef&?-Z)BF}]A";
$db = "allshopc_cpl";

$conn = mysqli_connect ($host,$user, $password, $db) or die ("Unable to connect");

?>